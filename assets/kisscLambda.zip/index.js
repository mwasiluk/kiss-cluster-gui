var AWS = require('aws-sdk');

exports.handler = (event, context, callback) => {
    
    let s3 = new AWS.S3();
    let iam = new AWS.IAM();
    
    let p1 = new Promise((resolve, reject) => {
        s3.listBuckets((err, data) => {
            if (err) {
               reject(err)
            } else   {
              resolve(data.Buckets);
            }
        });
    });
    
    let instanceProfiles;
    let p2 = new Promise((resolve, reject) => {
        iam.listInstanceProfiles((err, data) => {
            if (err) {
               reject(err)
            } else   {
               resolve(data.InstanceProfiles);
            }
        });
    }).then(_instanceProfiles=>{
        instanceProfiles = _instanceProfiles;
        return Promise.all(instanceProfiles.map(ip => Promise.all(ip.Roles.map(r => new Promise((resolve, reject) => {
            
            iam.listRolePolicies({RoleName: r.RoleName}, (err, data) => {
                if (err) {
                    reject(err)
                    return;
                }
                
                Promise.all(data.PolicyNames.map(policyName => new Promise((resolveRolePolicy, rejectRolePolicy) => iam.getRolePolicy({RoleName: r.RoleName, PolicyName: policyName}, (err, data) => {
                    if (err) {
                        rejectRolePolicy(err)
                        return;
                    }
                    data['PolicyDocument'] = JSON.parse(decodeURIComponent(data['PolicyDocument']))
                    resolveRolePolicy(data);
                    
                }))))
                .then(res => {
                    r['Policies'] = res;
                    resolve(r)
                });
            }); 
            
        })))));
        
    }).then(v=>{
        return instanceProfiles;
    });
    
    Promise.all([p1, p2]).then((values) => {
      callback(null, {
            Buckets: values[0],
            InstanceProfiles: values[1],
        });
    }).catch((e)=>{
        callback(e, null);
    });

};
