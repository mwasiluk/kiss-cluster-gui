var AWS = require('aws-sdk');

exports.handler = (event, context, callback) => {
    // TODO implement
    
    let s3 = new AWS.S3();
    let iam = new AWS.IAM();
    
    let p1 = new Promise(function(resolve, reject) {
        s3.listBuckets((err, data) => {
            if (err) {
               reject(err)
            } else   {
              resolve(data.Buckets);
            }
        });
    });
    
    let p2 = new Promise(function(resolve, reject) {
        iam.listInstanceProfiles((err, data) => {
            if (err) {
               reject(err)
            } else   {
              resolve(data.InstanceProfiles);
            }
        });
    });
    
    Promise.all([p1, p2]).then(function(values) {
        let res = {
            Buckets: values[0],
            InstanceProfiles: values[1],
        }
      console.log(res);
      callback(null, res);
    }).catch((e)=>{
        callback(e, null);
    });

};
